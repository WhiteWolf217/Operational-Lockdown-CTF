Hi Champ,
In this CTF or like a challenge for you to perform and submit the CTF.

Step 1. you will find a folder in this file named "Step1" but you wont be able to open that folder as its password protected.
	a. Don't Worry I got a hash for for you in which password is stored.(use any tools to find it like hashcat,etc)
	b. Identify the hash and crack it.
	hash ="4899806d04e473d55eef1f59a7548e86"
Step2.? go find it in the folder.
